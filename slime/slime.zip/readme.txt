License: CC0
Author: Rick Hoppmann

more resources and generators for games:
http://www.tinyworlds.org/resources.html
